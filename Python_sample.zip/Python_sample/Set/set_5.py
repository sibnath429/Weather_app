"""Write a Python program to create an intersection of sets."""

setx = set(["green", "blue"])
sety = set(["blue", "yellow"])
print("Original set elements:")
print(setx)
print(sety)
print("\nIntersection of two said sets:")
setz = setx & sety
print(setz)

"""Write a Python program to create a union of sets."""
setc1 = set(["green", "blue"])
setc2 = set(["blue", "yellow"])
print("Original sets: {} {}".format(setc1,setc2))
setc = setc1.union(setc2)
print("\nUnion of above sets: {}".format(setc))
setn1 = set([1, 1, 2, 3, 4, 5])
setn2 = set([1, 5, 6, 7, 8, 9])
print("\nOriginal sets: {} {}".format(setn1,setn2))
print("\nUnion of above sets:")
setn = setn1.union(setn2)
print(setn)