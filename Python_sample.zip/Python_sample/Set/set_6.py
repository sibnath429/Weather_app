"""Write a Python program to remove all elements from a given set."""

setc = {"Red", "Green", "Black", "White"}
print("Original set elements:")
print(setc)        
print("\nAfter removing all elements of the said set.")
setc.clear()
print(setc)