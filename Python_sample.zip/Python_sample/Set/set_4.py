"""Write a Python program to remove item(s) from a given set."""

"""Python | remove() and discard() in Sets"""
"""Difference : If there is no item for remove :discard method will give output but remove method will give error"""


# Python program to remove random elements of choice
# Function to remove elements using remove()
def Remove(sets):
    sets.remove("gaurav")
    print(sets)


# Driver Code
sets = set(["ram", "aakash", "kaushik", "anand", "prashant"])
Remove(sets)


""" Using discard"""


# Python program to remove random elements of choice
# Function to remove elements using discard()
def Remove(sets):
    sets.discard(20)
    print(sets)


# Driver Code
sets = set([10, 20, 26, 41, 54, 20])
Remove(sets)

