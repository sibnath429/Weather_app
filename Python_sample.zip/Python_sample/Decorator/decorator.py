"""Decorators are one of the most helpful and powerful tools of Python. These are used to modify the behavior of the
function. Decorators provide the flexibility to wrap another function to expand the working of wrapped function,
without permanently modifying it.
It is also called meta programming where a part of the program attempts to change another part of program at compile time.
"""


def start_end_decorator(func):
    def wrapper(*args, **kwargs):
        print("Start")
        a = func(*args, **kwargs)
        result = a + 10
        print("end")
        return result

    return wrapper


@start_end_decorator
def print_name(x):
    print('Alex')
    return x


# print_name = start_end_decorator(print_name)  # utilizing decorator func or

res_with_decor = print_name(20)
print(res_with_decor)


def uppercase_decorator(function):
    def wrapper():
        func = function()
        make_uppercase = func.upper()
        return make_uppercase

    return wrapper


def say_hi():
    return 'hello there'


decorate = uppercase_decorator(say_hi)
print(decorate())
