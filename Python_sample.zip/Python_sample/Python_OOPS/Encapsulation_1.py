# program to illustrate private access modifier in a class
"""Private Access Modifier: The members of a class that are declared private are accessible within the class only,
private access modifier is the most secure access modifier. Data members of a class are declared private by adding a
double underscore ‘__’ symbol before the data member of that class. """


class Geek:
    # private members
    __name = None
    __roll = None
    __branch = None
    _dept = None

    # constructor
    def __init__(self, name, roll, branch, dept):
        self.__name = name
        self.__roll = roll
        self.__branch = branch
        self._dept = dept

    # private member function
    def __displayDetails(self):
        # accessing private data members
        print("Name: ", self.__name)
        print("Roll: ", self.__roll)
        print("Branch: ", self.__branch)

    # public member function
    def accessPrivateFunction(self):
        # accessing private member function
        self.__displayDetails()

    def _access_protected(self):
        self.__displayDetails()
        print("Dept is: ", self._dept)


# creating object
# obj = Geek("R2J", 1706256, "Information Technology")


# calling public member function of the class
# obj.accessPrivateFunction()


class child(Geek):

    def __init__(self, name, roll, branch, dept):
        super(child, self).__init__(name, roll, branch, dept)


obj_child = child("sibnath", 4532, "CSE", "information technology")

obj_child.accessPrivateFunction()
obj_child._access_protected()  # Accessing protected method from derived class
