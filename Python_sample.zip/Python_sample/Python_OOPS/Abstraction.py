"""Abstraction is used to hide the internal functionality of the function from the users. The users only interact with the basic implementation of the function, but inner working is hidden.
 User is familiar with that "what function does" but they don't know "how it does."""

"""In Python, an abstraction is used to hide the irrelevant data/class in order to reduce the complexity. It also 
enhances the application efficiency. 
A class that consists of one or more abstract method is called the abstract class. 
Abstract methods do not contain their implementation.
"""
"""A class that consists of one or more abstract method is called the abstract class. Abstract methods do not contain 
their implementation. Abstract class can be inherited by the subclass and abstract method gets its definition in the 
subclass. Abstraction classes are meant to be the blueprint of the other class. An abstract class can be useful when 
we are designing large functions. An abstract class is also helpful to provide the standard interface for different 
implementations of components. Python provides the abc module to use the abstraction in the Python program. Let's see 
the following syntax. """

from abc import ABC, abstractmethod


class Computer(ABC):
    @abstractmethod
    def process(self):
        pass

    def show(self):
        print("concrete method")


com = Computer()
com.process()  # Can't instantiate abstract class Computer with abstract methods process
com.show()
