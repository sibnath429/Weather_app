"""When a class can be derived from more than one base class this type of inheritance is called multiple
inheritances. In multiple inheritances, all the features of the base classes are inherited into the derived class. """


# Creating a multiple inheritance using more than two classes.

class Car():
    def Benz(self):
        print(" This is a Benz Car ")


class Bike():
    def Bmw(self):
        print(" This is a BMW Bike ")


class Bus():
    def Volvo(self):
        print(" This is a Volvo Bus ")


class Truck():
    def Eicher(self):
        print(" This is a Eicher Truck ")


class Plane():
    def Indigo(self):
        print(" This is a Indigo plane ")


class Transport(Car, Bike, Bus, Truck, Plane):
    def Main(self):
        print("This is the Main Class")


B = Transport()
B.Benz()
B.Bmw()
B.Volvo()
B.Eicher()
B.Indigo()
B.Main()
