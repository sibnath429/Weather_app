"""
Encapsulation is one of the key concepts of object-oriented languages like Python, Java, etc. Encapsulation is used
to restrict access to methods and variables. In encapsulation, code and data are wrapped together within a single
unit from being modified by accident.

Encapsulation is a mechanism of wrapping the data (variables) and code acting on the data (methods) together as a
single unit. In encapsulation, the variables of a class will be hidden from other classes, and can be accessed only
through the methods of their current class. """

"""
Let us see the access modifiers in Python to understand the concept of Encapsulation and data hiding −
public
private
protected

--The public member is accessible from inside or outside the class.
--The private member is accessible only inside class. 
  Define a private member by prefixing the member name with two underscores : __age
--The protected member is accessible. from inside the class and its sub-class. 
  Define a protected member by prefixing the member name with an underscore : _points
"""



