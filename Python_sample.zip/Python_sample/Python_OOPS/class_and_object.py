"""A class is a user-defined blueprint or prototype from which objects are created. Classes provide a means of
bundling data and functionality together.
class ClassName:
    # Statement

Class creates a user-defined data structure, which holds its own data members and member functions, which can be
accessed and used by creating an instance of that class. A class is like a blueprint for an object. """


# Python3 program to
# demonstrate instantiating
# a class


class Dog:
    # A simple class
    # attribute
    attr1 = "mammal"
    attr2 = "dog"

    # A sample method
    def fun(self):
        print("I'm a", self.attr1)
        print("I'm a", self.attr2)


# Driver code
# Object instantiation
Rodger = Dog()

# Accessing class attributes
# and method through objects
print(Rodger.attr1)
Rodger.fun()

"""The __init__ method is similar to constructors in C++ and Java. Constructors are used to initialize the object’s 
state. Like methods, a constructor also contains a collection of statements(i.e. instructions) that are executed at 
the time of Object creation. It runs as soon as an object of a class is instantiated. The method is useful to do any 
initialization you want to do with your object. """
