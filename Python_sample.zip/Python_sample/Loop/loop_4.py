"""Way 3: Using iteritem(): iteritems() is used to loop through the dictionary printing the dictionary key-value pair
sequentially which is used before Python 3 version. """

# python code to demonstrate working of items()

d = {"geeks": "for", "only": "geeks"}

# iteritems() is renamed to items() in python3
# using items to print the dictionary key-value pair
print("The key value pair using items is : ")
for i, j in d.items():
	print(i, j)
