"""Python While Loop is used to execute a block of statements repeatedly until a given condition is satisfied. And
when the condition becomes false, the line immediately after the loop in the program is executed. Syntax:
while expression:
    statement(s)
"""

# Python program to illustrate
# while loop
count = 0
while (count < 3):
    count = count + 1
    print("Hello Geek")
