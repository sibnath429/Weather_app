if __name__ == "__main__" :

    string = input('Enter a string : ')

    # reverse a string using string slicing concept
    rev_string = string[::-1]

    print("reverse string :",rev_string)