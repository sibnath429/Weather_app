# Python program to find the
# maximum frequency character of the string

import collections
# Getting string input from the user
myStr =  input('Enter the string : ')

# Finding the maximum frequency character of the string
freq =  collections.Counter(myStr)
maxFreqChar = max(freq, key = freq.get)

# Printing values
print("Entered String is ", myStr)
print(maxFreqChar , "is the maximum frequency character with frequency of " , freq[maxFreqChar])