# Python program to pass a string to the function

# function definition: it will accept
# a string parameter and print it
def printMsg(str):
	# printing the parameter 
	print (str)

# Main code
# function calls
printMsg("Hello world!")
printMsg("Hi! I am good.")