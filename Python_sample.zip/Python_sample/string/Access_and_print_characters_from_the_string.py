# access characters in string

# declare, assign string 
str = "Hello world"

# print(complete string
print("str:", str)

# print(first character 
print("str[0]:", str[0])

# print(second character 
print("str[1]:", str[1])

# print(last character
print("str[-1]:", str[-1])

# print(second last character
print("str[-2]:", str[-2])

# print(characters from 0th to 4th index i.e.
# first 5 characters
print("str[0:5]:", str[0:5])

# print(characters from 2nd index to 2nd last index
print("str[2,-2]:", str[2:-2])

# print string character by character
print ("str:")
for i in str:
	print(i)
#comma after the variable
# it does not print new line