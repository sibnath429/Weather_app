# print EVEN length words of a string

# declare, assign string
str = "Python is a programming language"

new_str = str.split( )

print(new_str)

for element in new_str:
    if len(element)%2 == 0:
        print("EVEN length words:", element)