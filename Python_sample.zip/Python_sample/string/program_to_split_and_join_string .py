# Python program to split and join string

# Getting input from user
myStr = input('Enter the string : ')


# splitting and joining string
splitColl = myStr.split(' ')
joinedString = ' '.join(splitColl)
print(type(joinedString))

# printing values
print(splitColl)
print(joinedString)