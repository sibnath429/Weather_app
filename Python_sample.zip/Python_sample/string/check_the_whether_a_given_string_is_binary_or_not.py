# Python program to check whether a string
# is a binary string or not

# Getting string input from the user
myStr = input('Enter the binary string : ')

# check whether a string is binary string or not
flag = True
for char in myStr:
    if (char == '0' or char == '1'):
        continue
    else:
        flag = False
        print("The String is not a binary string")
        break

if (flag):
    print("The String is binary string")