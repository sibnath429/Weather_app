# python program to demonstrate example of string

# declaring & initializing two strings
str1 = "IncludeHelp"
str2 = ".com"

print (str1)          		# printing complete str1
print (str1[0])       		# printing 0th (first) elements of str1
print (str1[0], str1[1])	# printing first & second elements
print (str1[2:5])     		# printing elements from 2nd to 5th index
print (str1[1:])      		# printing all elements from 1st index
print (str2 * 2)  		# printing str2 two times
print (str1 + str2) 		# printing concatenated str1 & str2