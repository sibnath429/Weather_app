# python program to check substring
# presents in the string or not

# string and substring declaration, initialization
str = "IncludeHelp.Com"
sub_str ="Help"

if sub_str in str:
    print("present")
else:
    print("Not present")
