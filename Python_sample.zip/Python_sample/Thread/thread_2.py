"""
Daemon Threads:
A Daemon Thread is a type of thread that can run independently in the background.
These kinds of threads execute independently of the main thread. So these are called non-blocking threads.
"""

"""
Kind of tasks	Not critical like logging:
The best part about daemon threads is that they will automatically stop the execution once the main program finishes!
Daemon threads are extensively used for long-running background tasks --suppose we need to monitor backend any error
"""

"""We’ll make thread A perform a short computation, while thread B tries to monitor a shared resource."""

"To create a daemon thread, you set the daemon to True in the Thread constructor:"

# SuperFastPython.com
# example of creating a new daemon thread
from time import sleep
from threading import current_thread
from threading import Thread


# function to be executed in a new thread
def task():
    # get the current thread
    thread = current_thread()
    # report if daemon thread
    print(f'Daemon thread: {thread.daemon}')


# create a new daemon thread
thread = Thread(target=task, daemon=True)
# start the new thread
thread.start()
# block for a moment to let the daemon thread run
sleep(0.5)
