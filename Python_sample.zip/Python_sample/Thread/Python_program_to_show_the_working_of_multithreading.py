import threading

def ProcessOne():
    while(True):
        print("Process One")
def ProcessTwo():
    while(True):
        print("Process Two")

T1=threading.Thread(target=ProcessOne)
T2=threading.Thread(target=ProcessTwo)

T1.start()
T2.start()