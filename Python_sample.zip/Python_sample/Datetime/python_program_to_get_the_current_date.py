# Python program to get current date

# importing the date class
# from datetime module
from datetime import date

# getting the current date
current_date = date.today()

# printing the date
print("Current date is: ", current_date)