# importing the pytz module
import pytz

# printing the timezones using the for loop
for timezone in pytz.all_timezones:
  print (timezone)