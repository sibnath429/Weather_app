"""It helps you understand the version of python being in use."""
import sys
print(sys.version)


"""It’s a string that tells you where your filesystem or your python interpreter exists."""
import sys
print(sys.executable)


"""This helps you know about the platform. Everyone wants their program to run irrespective of the platform"""

print(sys.platform)

if sys.platform.startswith('win'):
    print('win')
elif sys.platform.startswith('aix'):
    print('aix')
elif sys.platform.startswith('darwin'):
    print('darwin')
elif sys.platform.startswith('linux'):
    print('linux')




"""In case of any exceptions in the program, there occurs the need of safe exit from the program. Sys.exit helps there."""


def is_namevalid(name):
    if any(i.isdigit() for i in name):
        print("ERROR: Invalid feature set ")
        sys.exit()

    else:
        print("Correct name")

is_namevalid("sibnath2")

"""These functions refers to file objects used by interpreter for the standard input, output and errors.

Stdin is for interactive input like we use input(), raw_input(). Input is taken through stdin.
Stdout is used for output like print(), output is printed actually through stdout.
Stderr is to prompt the error message"""

import sys
for j in (sys.stdin, sys.stdout, sys.stderr):
    print (j)



