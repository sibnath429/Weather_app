dict = {'key1': 'geeks', 'key2': 'for'}
print("Current Dict is: ", dict)

# adding dict1 (key3, key4 and key5) to dict
dict1 = {'key3': 'geeks', 'key4': 'is', 'key5': 'fabulous'}
dict.update(dict1)

# by assigning
dict.update(newkey='portal')
print(dict)