"""Write a Python program to remove a key from a dictionary"""

