"""Write a Python program to add a key to a dictionary.
Input: {0: 10, 1: 20}
Output : {0: 10, 1: 20, 2: 30}

"""

original_dict = {0: 10, 1: 20}
print("original dict {} ".format(original_dict))
original_dict.update({3: 12})
print("Modified dict {} ".format(original_dict))


