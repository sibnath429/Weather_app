"""The following program converts python dictionary to a list using the list map() function −."""

# input dictionary
inputDictionary = {'Hello': 10, 'Tutorialspoint': 20, 'python': 30}
# conveting list of keys and values of dictionary to a list using map() function
resultList = new_list = list(map(list, inputDictionary.items()))
# printing the resultant list of a dictionary key-values
print(resultList)

