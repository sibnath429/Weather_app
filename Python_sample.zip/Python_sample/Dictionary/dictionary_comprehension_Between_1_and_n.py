#Declare a dictionary and using dictionary comprehension
# initialize it to values keeping the number between 1 to n as the key and the square of the number as their values.
n=int(input("Enter a number:"))
d={x:x*x for x in range(1,n+1)}
print(d)