"""Shutil module offers high-level operation on a file like a copy, create, and remote operation on the file."""

"""shutil.copy() method in Python is used to copy the content of the source file to the destination file or directory."""

# importing shutil module
import shutil

# Source path
source = "C:\\Automation\\data.log"

# Destination path
destination = "C:\\Automation\\unknown"

# Copy the content of
# source to destination
dest = shutil.copy(source, destination)

# Print path of newly
# created file
print("Destination path:", dest)

import shutil

shutil.copystat("file_path", "path_to_file_where_you_want_to_copy")

"""move() to move a file
Below is the program to use move() to relocate a file from one location to another."""

import shutil

shutil.move("file_path", "path_to_where_you_want_to_move_file")

"""rmtree() to delete files from dirs and subdirs
This function removes all the contents of a directory recursively.shutil.rmtree("dir_path")"""


import shutil
targetdir = '/tmp/reports/';
# Clear a directory using rmtree()
try:
    shutil.rmtree(targetdir)
except:
    print("Operation failed!")