"""
Python: Square the elements of a list using map().

Original List:  [4, 5, 2, 9]
Square the elements of the said list using map():
[16, 25, 4, 81]

"""


def square_num(n):
    return n * n


original_list = [4, 5, 2, 9]
print("original list {}".format(original_list))
res = list(map(square_num, original_list))
print("Modified list after Square the elements {}".format(res))
