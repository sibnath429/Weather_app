"""
Write a Python program to listify the list of given strings individually using Python map.

Original list:
['Red', 'Blue', 'Black', 'White', 'Pink']

After listify the list of strings are:
[['R', 'e', 'd'], ['B', 'l', 'u', 'e'], ['B', 'l', 'a', 'c', 'k'], ['W', 'h', 'i', 't', 'e'], ['P', 'i', 'n', 'k']]
"""

original_list = ['Red', 'Blue', 'Black', 'White', 'Pink']
print("original list {}".format(original_list))
res = list(map(str, original_list))
print("After listify the list of strings are {}".format(res))

