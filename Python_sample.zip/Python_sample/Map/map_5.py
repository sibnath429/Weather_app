"""
Convert Tuple String to Tuple Integer

"""

test_tuple = ('1', '4', '3', '6', '7')

# Printing original tuple
print("Original tuple is : {}".format(test_tuple))

# using map() to
# perform conversion
test_tuple = tuple(map(int, test_tuple))

# Printing modified tuple
print("Modified tuple is : {}" .format(test_tuple))
