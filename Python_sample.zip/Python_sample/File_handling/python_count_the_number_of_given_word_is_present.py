import os
FILE_NAME_NORMAL = 'GFG.txt'
need_to_be_search = "sibnath"
os.path.join(os.path.dirname(os.path.abspath(__file__)),FILE_NAME_NORMAL)
i=0
with open('GFG.txt','r') as file:
    # reading each line
    for line in file:
        # reading each word
        for word in line.split():
            if need_to_be_search in word:
                # displaying the words
                i = i+1
print(need_to_be_search)
print(i)
