# importing os library
import os
def main():
    os.remove("pythonFiles")
    # creating a new directory
    os.mkdir("pythonFiles")

    # Changing current path to the directory
    os.chdir("pythonFiles")

    # creating a new file for writing operation
    fo = open("demo.txt", "w")
    fo.write("This is demo File")
    fo.close()

    fo = open("demo.txt", "a")
    fo.write("This is appending demo File")
    fo.close()

    # printing the current file directory
    print("Current Directory :", os.getcwd())





if __name__ == "__main__":
    main()
