import os

FILE_NAME_NORMAL = 'GFG.txt'
os.path.join(os.path.dirname(os.path.abspath(__file__)), FILE_NAME_NORMAL)
lines_seen = set()
outfile = open("GFG_modified.txt", 'w')
with open('GFG.txt', 'r') as file:
    # reading each line
    for line in file:
        if line not in lines_seen:  # not a duplicate
            outfile.write(line)
            lines_seen.add(line)
outfile.close()

