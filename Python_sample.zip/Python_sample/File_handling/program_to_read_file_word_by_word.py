# Python program to read
# file word by word
# opening the text file
import os
FILE_NAME_NORMAL = 'GFG.txt'
os.path.join(os.path.dirname(os.path.abspath(__file__)),FILE_NAME_NORMAL)
with open('GFG.txt','r') as file:
	# reading each line
	for line in file:

		# reading each word
		for word in line.split():

			# displaying the words
			print(word)



