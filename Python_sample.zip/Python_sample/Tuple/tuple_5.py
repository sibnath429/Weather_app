"""Creating tuple without using parenthesis in Python."""

# declaring tuple containing student's infomation
# without using parenthesis
student = "prem", 21, 98.56, "New Delhi"

# printing its type
print('Type of student:', type(student))

# printing the tuple
print("student: ", student)

# unpacking tuple and printing each values
name, age, perc, city = student
print('Name:', name)
print('Age:', age)
print('Percentage:', perc)
print('City: ', city)

