"""Write a Python program to convert a list of tuples into a dictionary."""

# initializing the list
tuples = [('Key 1', 1), ('Key 2', 2), ('Key 3', 3), ('Key 4', 4), ('Key 5', 5)]

# converting to dict
result = dict(tuples)

# printing the result
print(result)