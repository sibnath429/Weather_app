"""
Tuples are used to store multiple items in a single variable.
Tuple is one of 4 built-in data types in Python used to store collections of data.
A tuple is a collection which is ordered and unchangeable.

tuple1 = ("abc", 34, True, 40, "male")
"""

"""Write a Python program to create a tuple."""

#Create an empty tuple 
x = ()
print(x)
#Create an empty tuple with tuple() function built-in Python
tuplex = tuple()
print(tuplex)

