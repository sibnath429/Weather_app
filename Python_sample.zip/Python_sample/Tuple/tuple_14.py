"""Write a Python program to convert a given list of tuples to a list of lists"""

"""Original list of tuples: [(1, 2), (2, 3), (3, 4)]
Convert the said list of tuples to a list of lists:[[1, 2], [2, 3], [3, 4]]"""

Original_list_of_tuples = [(1, 2), (2, 3), (3, 4)]

res = list(map(list, Original_list_of_tuples))

print(res)
