"""Python programming provides us with a built-in @property decorator which makes usage of getter and setters much
easier in Object-Oriented Programming. """

