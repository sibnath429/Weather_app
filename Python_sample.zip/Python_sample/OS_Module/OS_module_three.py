"""This method returns a string value which represents the directory name from the specified path."""
import os.path

# Path
path = '/home/User/Documents'

# Get the directory name
# from the specified path
dirname = os.path.dirname(path)

# Print the directory name
print(dirname)

"""This method returns a floating-point value of class ‘float’ that represents the time (in seconds) of last modification of the specified path"""

import os
import time

# Path
path = '/home/User/Documents/file.txt'

# Get the time of last
# modification of the specified
# path since the epoch
modification_time = os.path.getmtime(path)
print("Last modification time since the epoch:", modification_time)

# convert the time in
# seconds since epoch
# to local time
local_time = time.ctime(modification_time)
print("Last modification time(Local time):", local_time)


"""This method returns a normalised absolute version of the specified path."""

import os.path

# file name
file_name = 'GFG.txt'

# prints the absolute path of current
# working directory with  file name
print(os.path.abspath(file_name))

"""This method returns True if specified path is an existing regular file, otherwise returns False."""
import os

# Path
path = '/home/User/Desktop/file.txt'

# Check whether the
# specified path is
# an existing file
isFile = os.path.isfile(path)
print(isFile)

"""This methods checks and reports whether the specified pathname corresponds to an existing directory or not"""
import os.path

# Path
path = '/home/User/Documents/file.txt'

# Check whether the
# specified path is an
# existing directory or not
isdir = os.path.isdir(path)
print(isdir)


"""This method returns True if path exists otherwise returns False."""
import os

# Specify path
path = '/usr/local/bin/'

# Check whether the specified
# path exists or not
isExist = os.path.exists(path)
print(isExist)



