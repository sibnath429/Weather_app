list = [10, 20, 10, 30, 10, 40, 10, 50]
new_list = []
for remove_list in list:
    if remove_list not in new_list:
        new_list.append(remove_list)
print(new_list)

