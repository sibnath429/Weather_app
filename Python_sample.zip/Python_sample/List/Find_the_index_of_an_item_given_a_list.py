test_list = ['bangalore','chennai','mangalore','vizag','delhi']
print(test_list.index('bangalore'))

test_list_1 = [1,2,3,4,5]
print(test_list_1.index(4))