# Python program to clone or copy list
# using copy method

# Getting list from user
print("***********Program to clone or copy list using copy method in Python*******")
myList = []
length = int(input("Enter number of elements : "))
for i in range(0, length):
    value = int(input())
    myList.append(value)

# cloning the list
copyList = myList.copy()

# Printing lists
print("Entered List ", myList)
print("Cloned List ", copyList)



