list = [10, 1, 2, 20, 3, 20]

list[2] = 50

print(list)


list_new = [10, 20, 30]

print (list_new)

list_new.insert (1, "ABC")

print (list_new)