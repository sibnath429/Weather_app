print("***********Program to clone a list using deep or shallow copy technique*******")
# Python program to clone or copy list using
# deep copy or shallow copy method

import copy

# Getting list from user
myList = []
length = int(input("Enter number of elements : "))
for i in range(0, length):
    value = int(input())
    myList.append(value)

# cloning the list
shallowCopyList = copy.copy(myList)
deepCopyList = copy.deepcopy(myList)

# Printing lists
print("Entered List ", myList)
print("Deep Copy List ", deepCopyList)
print("Shallow Copy List ", shallowCopyList)