my_list = [2, 5, 13, 17, 51, 62, 73, 84, 95]

temp = my_list[0]
my_list[0] = my_list[-1]

my_list[-1] = temp

print(my_list)




