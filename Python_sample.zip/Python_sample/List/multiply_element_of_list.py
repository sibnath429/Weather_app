# Getting list from user
myList = []
length = int(input("Enter number of elements: "))
for i in range(0, length):
    value = int(input())
    myList.append(value)


# multiplying all numbers of a list
productVal = 1
for i in myList:
    productVal *= i

print("List::",myList)
print("Multiply::",productVal)
