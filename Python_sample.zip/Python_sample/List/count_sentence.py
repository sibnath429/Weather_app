s = 'I am having a very nice day.'
print(s.split())
print(len(s.split())) # print no of word