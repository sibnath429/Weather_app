# Python program to remove empty list
# from a list of lists

# Initializing list of lists
listofList = [[5], [54, 545,9], [], [1, 4, 7], [], [8, 2, 5] ]

# Printing original list
print("List of List = ", end = " ")
print(listofList)

nonEmptyList = []

# Iterating using loop and eliminating empty list
nonEmptyList = [listEle for listEle in listofList if listEle != []]

# for ele in listofList:
#     if ele != []:
#         nonEmptyList.append(ele)


# Printing list without empty list
print("List without empty list: ", end = " " )
print(nonEmptyList)