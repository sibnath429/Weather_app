#Put Even and Odd elements in a List
my_list = [2, 5, 13, 17, 51, 62, 73, 84, 95]
even_list = []
odd_list = []
for i in my_list:
    if (i % 2 == 0):
        even_list.append(i)
    else:
        odd_list.append(i)
print("The list of odd numbers are :", even_list)
print("The list of even numbers are :", odd_list)

