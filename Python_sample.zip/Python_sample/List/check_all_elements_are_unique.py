# function to check unique
def check_unique(x):
  return len(x) == len(set(x))

# lists
x = [10, 20, 30, 40,50]
y = [10, 20, 20, 20, 20]
z = [10, 10, 10, 10, 10]

print("x: ", x)
print("len(x): ", len(x))
print("set(x): ", set(x))
print("len(set(x)): ", len(set(x)))
print("check_unique(x): ", check_unique(x))
print()

print("y: ", y)
print("len(y): ", len(y))
print("set(y): ", set(y))
print("len(set(y)): ", len(set(y)))
print("check_unique(y): ", check_unique(y))
print()

print("z: ", z)
print("len(z): ", len(z))
print("set(z): ", set(z))
print("len(set(z)): ", len(set(z)))
print("check_unique(z): ", check_unique(z))
print()