import random
def random_gen(beg, end):
   my_result = []
   for j in range(1,20):
      my_result.append(random.randint(beg, end))
   return my_result
beg = 1
end = 20
print("The start and end values are :")
print(beg, end)
print("The elements are : ")
print(random_gen(beg, end))