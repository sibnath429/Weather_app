a_list = [5, 2, 6, 19]
b_list = [26, 29, 41, 49, 31]

new_list = sorted(a_list + b_list)

print("Sorted list is:",new_list )