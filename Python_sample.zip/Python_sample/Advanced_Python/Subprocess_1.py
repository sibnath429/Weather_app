"""The subprocess is a standard Python module designed to start new processes from within a Python script. Run a
Python File Using Another Python File Using Subprocess :https://www.golinuxcloud.com/python-subprocess/.

The main idea behind the subprocess library is to be able to
interact with the OS by executing any commands we want, directly from the Python interpreter.

For example, if you open multiple windows of your web browser at the same time,
each of those windows is a different process of the web browser program
"""

"""subprocess.Popen(In order to create a subprocess )The P in the name of the Popen() function stands for process."""
"""shell =True/False avoid shell=True"""
"""universal_newlines --> To get output as string or else it'll print output as bytecode: decode("utf-8")
                          universal_newlines"""
"""communicate(): In this code if you observe we are storing the STDOUT and STDERR into the sp variable and later using communicate() method,
   we separate the output and error individually into two different variables"""

import subprocess

# Define command as string and then split() into list format
cmd = 'ping -c 5 google.com'

# Use shell to execute the command, store the stdout and stderr in sp variable
sp = subprocess.Popen(cmd,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)

"""Store the return code in rc variable"""
rc = sp.wait()
"""Separate the output and error by communicating with sp variable.
This is similar to Tuple where we store two values to two different variables"""
out,err=sp.communicate()

print('Return Code:',rc,'\n')
print('output is: \n', out)
print('error is: \n', err)

""" However, the use shell=True has many downsides, and the worst are the possible security leaks.
    subprocess.run('ls -la', shell=True) # Dangerous command
"""
""" if shell=True then your cmd is string(as your OS command)
    if shell=False then your cmd is a list

ex:cmd="ls -lrt"  ==> shell=True
   shell=False ==> cmd="ls -lrt".split() or ['ls','-lrt']
"""


