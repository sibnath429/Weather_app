"""By default Python‘s print() function ends with a newline. A programmer with C/C++ background may wonder how to
print without a newline. Python’s print() function comes with a parameter called ‘end‘. By default, the value of this
parameter is ‘\n’, i.e. the new line character.

"""

# using "in" to loop through
for i in 'geeksforgeeks':
    print(i, end=" ")