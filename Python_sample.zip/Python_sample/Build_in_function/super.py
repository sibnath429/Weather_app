"""A Python can do both structured programming and Object-oriented programming as well. The Python super() function
is a built-in function used mainly in object-oriented programming. The basic knowledge of OOP is required to
understand the purpose and the use of the python super() function. One of the important features of OOP is
inheritance, where a new class can be created which takes all the properties from an existing class known as parent
class. The python super() function is used in the child class to refer to the parent class and access all the parent
class's functions and variables. In this tutorial, we will learn how we can get access to the methods and variables
of the parent class using the python super() function inside the child class.

super().method_name
"""


# parent class
class University:

    # constructor
    def __init__(self, Univeristy_name):
        # prints the name of university
        print(Univeristy_name, 'is the name of university.')


# child class
class Faculty(University):

    # constructor
    def __init__(self):
        # prints total faculty
        print('Total faculty numbers is 300.')

        # get access to parent class using python init super function
        super().__init__('UCA')


# object type of Faculty
uni = Faculty()