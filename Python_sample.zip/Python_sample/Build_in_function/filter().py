"""
The filter functions can be applied to an iterable such as a list, or a dictionary and create a new iterator that can
filter out certain specific elements based on the condition that we provided.

The filter function returns a sequence from those elements of iterable for which function returns True.
The first argument can be None if the function is not available and returns only elements that are True.
"""

"""filter(function, iterable)"""

# Python filter() function example
# Calling function
result = filter(None,(1,0,6)) # returns all non-zero values
result2 = filter(None,(1,0,False,True)) # returns all non-zero and True values
# Displaying result
result = list(result)
result2 = list(result2)
print(result)
print(result2)

"""
Output:
[1, 6]
[1, True]
"""
