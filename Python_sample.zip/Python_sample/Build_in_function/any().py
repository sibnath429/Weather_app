"""Python any() function is a built-in function that is used to check the items of multiple data type objects like
lists, tuples, dictionaries, etc that contains true, then the python any() function will return true as well.
"""
"""the any() function takes and iterable as an argument and returns True if at least one of the items in the iterable 
is true. It returns True if bool(iterable_name) is True for any of the iterable. And return False if the bool(
iterable_name) is False. """

# string one
string1 = "Bashir"

# string two
string2 = "1234"

# string three
string3 = "@#$"

# apply python any() function
print(any(string1))
print(any(string2))
print(any(string3))

"""Output"""
"""True
   True
   True"""

"""We get false in the first case because it was an empty string, while in the second case we get True because 
whitespaces in python are valid string types. below::"""

# string one
string1 = ""

# string two

string2 = "  "

# apply python any() function
print(any(string1))
print(any(string2))

"""Output"""
"""
False
True
"""

# list one
list1 = []

# list two
list2 = ["b", "a", "s", "h"]

# list three
list3 = [1, 2, 3, 4]

# using any() function
print(any(list1))
print(any(list2))
print(any(list3))

"""
Output:
False
True
True
"""

""" a list containing all zeros values will also return False because in python zero is considered to be False."""

# list containing zeros
list1 = [0, 0, 0, 0, 0, 0, 0]

# python any() function
print(any(list1))

"""Output:
False"""

"""Now if a list containing zeros but not as numeric values but as strings, then it will return True because this 
time python will treat them as strings rather than a numeric value. """

# list containing zeros
list1 = ["0", "0", "0", "0", "0", "0", "0"]

# python any() function
print(any(list1))

"""Output:
True"""
