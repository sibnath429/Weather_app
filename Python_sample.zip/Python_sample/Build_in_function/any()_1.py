# string one
string1 = "3444543"

# string two
string2 = "#$#%))"

# string three
string3 = "%#$sdfadfgfg"

# checking for letter
letter1 = [char.isdigit() for char in string1]
letter2 = [char.isdigit() for char in string2]
letter3 = [char.isdigit() for char in string3]

# checking using multiple conditions
if any(letter1) or any(letter2) or any(letter3):
   print("At least one of them has numeric value")
else:
   print("Not all of them have numeric values")

"""Output:
At least one of them has numeric value"""



# string one
string1 = "3444543"

# string two
string2 = "#$#%))"

# string three
string3 = "%#$sdfadfgfg"

# checking for letter
letter1 = [char.isalpha() for char in string1]
letter2 = [char.isalpha() for char in string2]
letter3 = [char.isalpha() for char in string3]

# printing
print(any(letter1))
print(any(letter2))
print(any(letter3))

"""
Output:
False
False
True
"""