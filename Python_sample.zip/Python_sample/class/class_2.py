
"""Define a Python function student(). Using function attributes display the names of all arguments."""

def student(student_id, student_name, student_class):
    return f'Student ID: {student_id}\nStudent Name: {student_name}\nClass: {student_class}'
print(student('S122', 'Wilson Medina', 'VI'))