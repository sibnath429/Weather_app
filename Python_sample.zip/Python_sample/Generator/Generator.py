"""A generator-function is defined like a normal function, but whenever it needs to generate a value, it does so with
the yield keyword rather than return. If the body of a def contains yield, the function automatically becomes a
generator function.

Generator-Object : Generator functions return a generator object. Generator objects are used either by calling the
next method on the generator object or using the generator object in a “for in” loop (as shown in the above program).

So a generator function returns an generator object that is iterable, i.e., can be used as an Iterators .
"""


def disp(a, b):
    yield a
    yield b


result = disp(5, 2)
print(result) # Print as a object
print(type(result)) # type generator
print(list(result))# Print as a object

