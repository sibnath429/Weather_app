def fave_language(language="python"):
    print(f"My favorite  programming language is {language}!")


File_name = "TPM2ProvFiles"
cmd = r'ls \{}'.format(File_name)
fave_language(cmd)
# prints "My favorite  programming language is Java!" to the console
