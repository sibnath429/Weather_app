# Python program to display OS name

# import module
import platform

# displaying OS name
print('Operating system:', platform.system())
# displaying platform processor name
print('Platform processor:', platform.platform())

# displaying platform architecture
print('Platform architecture:', platform.architecture())

# displaying platform processor
print('Platform processor:', platform.processor())